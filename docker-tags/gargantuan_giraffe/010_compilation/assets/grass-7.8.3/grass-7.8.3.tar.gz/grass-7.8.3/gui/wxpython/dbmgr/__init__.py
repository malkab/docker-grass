all = [
    'g.gui.dbmgr',
    'sqlbuilder',
    'vinfo',
    'manager',
    'base',
    'dialogs',
]
