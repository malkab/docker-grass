all = [
    'dialogs',
    'controllers',
    'frame',
    'plots',
    'iscatt_core',
    'toolbars',
    'core_c',
]
