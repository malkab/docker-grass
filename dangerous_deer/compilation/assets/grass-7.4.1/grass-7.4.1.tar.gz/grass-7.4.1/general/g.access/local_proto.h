/* exp_perms.c */
char *explain_perms(int, int, int);

/* get_perms.c */
int get_perms(char *, int *, int *, int *);

/* set_perms.c */
int set_perms(char *, int, int, int);
