all = [
    'controller',
    'toolbars'
]
