all = [
    'ii2t_manager',
    'ii2t_mapdisplay',
    'ii2t_toolbars',
]
