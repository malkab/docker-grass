all = [
    'manager',
    'mapdisplay',
    'toolbars',
]
