/* element.c */
void list_elements();
int  check_element(const char *);
