all = [
    'catalog',
    'frame',
    'tree',
    'dialogs'
]
